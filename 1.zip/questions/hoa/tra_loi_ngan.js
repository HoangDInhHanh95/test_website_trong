

if (typeof questions === 'undefined') {
    questions = {};
}

if (typeof questions.hoa === 'undefined') {
    questions.hoa = {};
}

questions.hoa.tra_loi_ngan = [

    {
        question: "đề bài 1",
        answer: "đáp án 1",
        solution: "lời giải chi tiết 1"
        },
        {
        question: "đề bài 2",
        answer: "đáp án 2",
        solution: "lời giải chi tiết 2"
        },
        {
        question: "đề bài 3",
        answer: "đáp án 3",
        solution: "lời giải chi tiết 3"
        },
        {
        question: "đề bài 4",
        answer: "đáp án 4",
        solution: "lời giải chi tiết 4"
        },
        {
        question: "đề bài 5",
        answer: "đáp án 5",
        solution: "lời giải chi tiết 5"
        },
        {
        question: "đề bài 6",
        answer: "đáp án 6",
        solution: "lời giải chi tiết 6"
        },
        {
        question: "đề bài 7",
        answer: "đáp án 7",
        solution: "lời giải chi tiết 7"
        },
        {
        question: "đề bài 8",
        answer: "đáp án 8",
        solution: "lời giải chi tiết 8"
        },
        {
        question: "đề bài 9",
        answer: "đáp án 9",
        solution: "lời giải chi tiết 9"
        },
        {
        question: "đề bài 10",
        answer: "đáp án 10",
        solution: "lời giải chi tiết 10"
        },
        {
        question: "đề bài 11",
        answer: "đáp án 11",
        solution: "lời giải chi tiết 11"
        },
        {
        question: "đề bài 12",
        answer: "đáp án 12",
        solution: "lời giải chi tiết 12"
        },
        {
        question: "đề bài 13",
        answer: "đáp án 13",
        solution: "lời giải chi tiết 13"
        },
        {
        question: "đề bài 14",
        answer: "đáp án 14",
        solution: "lời giải chi tiết 14"
        },
        {
        question: "đề bài 15",
        answer: "đáp án 15",
        solution: "lời giải chi tiết 15"
        },
        {
        question: "đề bài 16",
        answer: "đáp án 16",
        solution: "lời giải chi tiết 16"
        },
        {
        question: "đề bài 17",
        answer: "đáp án 17",
        solution: "lời giải chi tiết 17"
        },
        {
        question: "đề bài 18",
        answer: "đáp án 18",
        solution: "lời giải chi tiết 18"
        },
        {
        question: "đề bài 19",
        answer: "đáp án 19",
        solution: "lời giải chi tiết 19"
        },
        {
        question: "đề bài 20",
        answer: "đáp án 20",
        solution: "lời giải chi tiết 20"
        },
        {
        question: "đề bài 21",
        answer: "đáp án 21",
        solution: "lời giải chi tiết 21"
        },
        {
        question: "đề bài 22",
        answer: "đáp án 22",
        solution: "lời giải chi tiết 22"
        },
        {
        question: "đề bài 23",
        answer: "đáp án 23",
        solution: "lời giải chi tiết 23"
        },
        {
        question: "đề bài 24",
        answer: "đáp án 24",
        solution: "lời giải chi tiết 24"
        },
        {
        question: "đề bài 25",
        answer: "đáp án 25",
        solution: "lời giải chi tiết 25"
        },
        {
        question: "đề bài 26",
        answer: "đáp án 26",
        solution: "lời giải chi tiết 26"
        },
        {
        question: "đề bài 27",
        answer: "đáp án 27",
        solution: "lời giải chi tiết 27"
        },
        {
        question: "đề bài 28",
        answer: "đáp án 28",
        solution: "lời giải chi tiết 28"
        },
        {
        question: "đề bài 29",
        answer: "đáp án 29",
        solution: "lời giải chi tiết 29"
        },
        {
        question: "đề bài 30",
        answer: "đáp án 30",
        solution: "lời giải chi tiết 30"
        },
        {
        question: "đề bài 31",
        answer: "đáp án 31",
        solution: "lời giải chi tiết 31"
        },
        {
        question: "đề bài 32",
        answer: "đáp án 32",
        solution: "lời giải chi tiết 32"
        },
        {
        question: "đề bài 33",
        answer: "đáp án 33",
        solution: "lời giải chi tiết 33"
        },
        {
        question: "đề bài 34",
        answer: "đáp án 34",
        solution: "lời giải chi tiết 34"
        },
        {
        question: "đề bài 35",
        answer: "đáp án 35",
        solution: "lời giải chi tiết 35"
        },
        {
        question: "đề bài 36",
        answer: "đáp án 36",
        solution: "lời giải chi tiết 36"
        },
        {
        question: "đề bài 37",
        answer: "đáp án 37",
        solution: "lời giải chi tiết 37"
        },
        {
        question: "đề bài 38",
        answer: "đáp án 38",
        solution: "lời giải chi tiết 38"
        },
        {
        question: "đề bài 39",
        answer: "đáp án 39",
        solution: "lời giải chi tiết 39"
        },
        {
        question: "đề bài 40",
        answer: "đáp án 40",
        solution: "lời giải chi tiết 40"
        },
        {
        question: "đề bài 41",
        answer: "đáp án 41",
        solution: "lời giải chi tiết 41"
        },
        {
        question: "đề bài 42",
        answer: "đáp án 42",
        solution: "lời giải chi tiết 42"
        },
        {
        question: "đề bài 43",
        answer: "đáp án 43",
        solution: "lời giải chi tiết 43"
        },
        {
        question: "đề bài 44",
        answer: "đáp án 44",
        solution: "lời giải chi tiết 44"
        },
        {
        question: "đề bài 45",
        answer: "đáp án 45",
        solution: "lời giải chi tiết 45"
        },
        {
        question: "đề bài 46",
        answer: "đáp án 46",
        solution: "lời giải chi tiết 46"
        },
        {
        question: "đề bài 47",
        answer: "đáp án 47",
        solution: "lời giải chi tiết 47"
        },
        {
        question: "đề bài 48",
        answer: "đáp án 48",
        solution: "lời giải chi tiết 48"
        },
        {
        question: "đề bài 49",
        answer: "đáp án 49",
        solution: "lời giải chi tiết 49"
        },
        {
        question: "đề bài 50",
        answer: "đáp án 50",
        solution: "lời giải chi tiết 50"
        }
]